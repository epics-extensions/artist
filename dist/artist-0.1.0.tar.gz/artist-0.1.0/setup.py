# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['artist']

package_data = \
{'': ['*']}

install_requires = \
['graphviz>=0.20.1,<0.21.0', 'pyepics>=3.5.2,<4.0.0']

entry_points = \
{'console_scripts': ['artist = artist.artist:main']}

setup_kwargs = {
    'name': 'artist',
    'version': '0.1.0',
    'description': '',
    'long_description': '# ARTIST\nAdvanced Representation of MRF TIming System Topology\n``` mermaid\nflowchart\n  2 <-->|Port 1| 21[mTCA-EVR-300]\n  2 <-->|Port 2| 22[mTCA-EVR-300]\n  0[EVM Master] <-->|Port 1| 1[mTCA-EVR-300]\n  0[EVM Master] <-->|Port 3| 3[PCIe-EVR-300DC]\n  0[EVM Master] <-->|Port 2| 2[EVM Fanout]\n```\n',
    'author': 'Alexis Gaget',
    'author_email': 'alexis.gaget@cea.fr',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.11,<4.0',
}


setup(**setup_kwargs)
